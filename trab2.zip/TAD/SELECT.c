#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include "util.h"
#include "buscar.h"

// Imprime todos os registros não removidos do arquivo que satisfaçam as 'm' condições.

// arquivoBin: Nome do arquivo a ser lido.
// n: Quantidade de buscas a ser feitas
void SELECT(char *arquivoBIN, int n) {
    // Abrindo o arquivo
    FILE *arquivo;
    arquivo = fopen(arquivoBIN,"rb+");
    if(arquivo == NULL) {
        printf("Falha no processamento do arquivo.\n");
        return;
    }

    // Checa se o arquivo é instável
    char status = '0';
    fread(&status, sizeof(char), 1, arquivo);
    if(status == '0') {
        printf("Falha no processamento do arquivo.\n");
        fclose(arquivo);
        return;
    }

    // Marca o arquivo instável
    fseek(arquivo, 0, SEEK_SET);
    fwrite(&c_zero,sizeof(char),1,arquivo);

    // Iterando por cada busca
    for(int i = 0; i < n; i++){
        int m; // Quantidade de condições
        estacao temp;
        nulifica_estacao(&temp);

        scanf("%d",&m);
        pegar_info_estacao(&temp,m); // Pega quais condições a estação tem q satisfazer e deixa no temp. 
        // Caso um campo seja NULO, ele é representado no 'temp' por -2
        // Caso um campo não seja especificado (não é uma condição para buscar), ele é representado por -1
        
        iterar_estacao(&temp, arquivo, F_SELECT, NULL);
        // tem q imprimir uma quebra de linha no final
        printf("\n");

        // Desalocando memória.
        if(temp.nomeEstacao != NULL) free(temp.nomeEstacao);
        if(temp.nomeLinha != NULL) free(temp.nomeLinha);
        temp.nomeEstacao = NULL;
        temp.nomeLinha = NULL;
    }

    // Marca o arquivo como estável para uso e fecha
    fseek(arquivo,0,SEEK_SET);
    fwrite(&c_um,sizeof(char),1,arquivo);
    fclose(arquivo);

    return;
}