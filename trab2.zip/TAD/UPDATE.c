#include "UPDATE.h"

void UPDATE(char *arquivoBIN,int vezes) {
    FILE *arquivo = fopen(arquivoBIN,"rb+");
    if(arquivo == NULL) {
        printf("Falha no processamento do arquivo.\n");
        return;
    }
    
    // Checa se o arquivo é instável
    char status = '0';
    fread(&status, sizeof(char), 1, arquivo);
    if(status == '0') {
        printf("Falha no processamento do arquivo.\n");
        fclose(arquivo);
        return;
    }

    // Marca o arquivo como instável
    fseek(arquivo, 0, SEEK_SET);
    fwrite(&c_zero,sizeof(char),1,arquivo);

    for(int i = 0; i < vezes; i++) {
        int m;

        // definição das estações antiga que deve ser atualizada
        estacao temp;
        nulifica_estacao(&temp);
        scanf("%d",&m);
        pegar_info_estacao(&temp,m);

        // transformar é as novas informações a serem colocandos sobrepostas na estação antiga
        estacao transformar;
        scanf("%d",&m);
        nulifica_estacao(&transformar);
        pegar_info_estacao(&transformar,m);

        // Passa por cada estação e faz o update. Função feita em util.h
        iterar_estacao(&temp, arquivo, F_UPDATE, &transformar);

        // liberando memória
        if(temp.nomeEstacao != NULL) free(temp.nomeEstacao);
        if(temp.nomeLinha != NULL) free(temp.nomeLinha);
        temp.nomeEstacao = NULL;
        temp.nomeLinha = NULL;

        if(transformar.nomeEstacao != NULL) free(transformar.nomeEstacao);
        if(transformar.nomeLinha != NULL) free(transformar.nomeLinha);
        transformar.nomeEstacao = NULL;
        transformar.nomeLinha = NULL;
    }

    // Note que não está sendo feita a atualização de qtd de estação e pares, pois foi especificado que o comando de UPDATE não irá alterar esses valores.
    fseek(arquivo, 0, SEEK_SET);
    fwrite(&c_um,sizeof(char),1,arquivo);
    fclose(arquivo);
    BinarioNaTela(arquivoBIN);
}