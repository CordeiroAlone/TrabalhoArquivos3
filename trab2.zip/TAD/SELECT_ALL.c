#include "util.h"
#include "buscar.h"

// Imprime todos os registros não removidos do arquivo.

// arquivoBin: Nome do arquivo a ser lido.
void SELECT_ALL(char *arquivoBIN) {
    // Abrindo o arquivo
    FILE *arquivo;
    arquivo = fopen(arquivoBIN,"rb+");
    // Tratamento de erro
    if(arquivo == NULL) {
        printf("Falha no processamento do arquivo.\n");
        return;
    }

    // Checa se o arquivo é instável
    char status = '0';
    fread(&status, sizeof(char), 1, arquivo);
    if(status == '0') {
        printf("Falha no processamento do arquivo.\n");
        fclose(arquivo);
        return;
    }

    // Marca o arquivo instável
    fseek(arquivo, 0, SEEK_SET);
    fwrite(&c_zero,sizeof(char),1,arquivo);

    estacao temp;
    nulifica_estacao(&temp);

    // Note que como temp foi "nulificado", qualquer estação do registro vai satisfazer a base(temp), logo, todos vão ser impressos.
    iterar_estacao(&temp, arquivo, F_SELECT, NULL);
    
    // Marca o arquivo como estável e o fecha.
    fseek(arquivo,0,SEEK_SET);
    fwrite(&c_um,sizeof(char),1,arquivo);
    fclose(arquivo);

    return;
}